using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using OnlineExamination.Models;

namespace OnlineExamination.Data;

public static class DbInitializer
{
    public static async Task InitializeAsync(ApplicationDbContext db)
    {
        if (!await db.Teachers.AnyAsync())
        {
            var hasher = new PasswordHasher<Teacher>();
            var teacher = new Teacher
            {
                FullName = "Demo Teacher",
                Email = "teacher@examsphere.com",
                Subject = "Information Technology"
            };
            teacher.PasswordHash = hasher.HashPassword(teacher, "Teacher@123");
            db.Teachers.Add(teacher);
        }

        if (!await db.Students.AnyAsync())
        {
            var hasher = new PasswordHasher<Student>();
            var student = new Student
            {
                FullName = "Demo Student",
                Email = "student@examsphere.com",
                RollNumber = "01",
                ClassName = "SY",
                Division = "A"
            };
            student.PasswordHash = hasher.HashPassword(student, "Student@123");
            db.Students.Add(student);
        }

        if (!await db.Exams.AnyAsync())
        {
            await db.SaveChangesAsync();
            var teacher = await db.Teachers.FirstAsync();
            var exam = new Exam
            {
                Title = "Web Technology Fundamentals",
                Description = "A short demonstration examination covering HTML, CSS, JavaScript and web fundamentals.",
                DurationMinutes = 15,
                StartDate = DateTime.Now.AddDays(-1),
                EndDate = DateTime.Now.AddMonths(6),
                TargetClass = "SY",
                TargetDivision = "A",
                TeacherId = teacher.TeacherId,
                TotalMarks = 10
            };
            exam.Questions.Add(new Question
            {
                QuestionText = "Which language is used to structure a web page?",
                Marks = 2,
                Options = new List<Option>
                {
                    new() { OptionText = "HTML", IsCorrect = true },
                    new() { OptionText = "CSS" },
                    new() { OptionText = "SQL" },
                    new() { OptionText = "Python" }
                }
            });
            exam.Questions.Add(new Question
            {
                QuestionText = "Which technology is primarily used to style HTML elements?",
                Marks = 2,
                Options = new List<Option>
                {
                    new() { OptionText = "CSS", IsCorrect = true },
                    new() { OptionText = "C#" },
                    new() { OptionText = "SQL" },
                    new() { OptionText = "XML" }
                }
            });
            exam.Questions.Add(new Question
            {
                QuestionText = "Which keyword declares a constant in modern JavaScript?",
                Marks = 2,
                Options = new List<Option>
                {
                    new() { OptionText = "const", IsCorrect = true },
                    new() { OptionText = "constant" },
                    new() { OptionText = "fixed" },
                    new() { OptionText = "letonly" }
                }
            });
            exam.Questions.Add(new Question
            {
                QuestionText = "What does SQL commonly manage?",
                Marks = 2,
                Options = new List<Option>
                {
                    new() { OptionText = "Relational data", IsCorrect = true },
                    new() { OptionText = "Images only" },
                    new() { OptionText = "CSS styles" },
                    new() { OptionText = "Audio drivers" }
                }
            });
            exam.Questions.Add(new Question
            {
                QuestionText = "Which HTTP method is commonly used to submit form data?",
                Marks = 2,
                Options = new List<Option>
                {
                    new() { OptionText = "POST", IsCorrect = true },
                    new() { OptionText = "STYLE" },
                    new() { OptionText = "FETCHONLY" },
                    new() { OptionText = "FORM" }
                }
            });
            db.Exams.Add(exam);
        }

        await db.SaveChangesAsync();
    }
}
