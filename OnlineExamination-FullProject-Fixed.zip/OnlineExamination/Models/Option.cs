using System.ComponentModel.DataAnnotations;

namespace OnlineExamination.Models;

public class Option
{
    public int OptionId { get; set; }

    [Required, StringLength(500)]
    public string OptionText { get; set; } = "";

    public bool IsCorrect { get; set; }

    public int QuestionId { get; set; }
    public Question? Question { get; set; }
}
