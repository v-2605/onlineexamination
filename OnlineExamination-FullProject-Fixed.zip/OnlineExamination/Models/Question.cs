using System.ComponentModel.DataAnnotations;

namespace OnlineExamination.Models;

public class Question
{
    public int QuestionId { get; set; }

    [Required, StringLength(1000)]
    public string QuestionText { get; set; } = "";

    [Range(1, 100)]
    public int Marks { get; set; } = 1;

    public int ExamId { get; set; }
    public Exam? Exam { get; set; }

    public ICollection<Option> Options { get; set; } = new List<Option>();
}
