using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OnlineExamination.Data;

namespace OnlineExamination.Controllers;

public class StudentController : Controller
{
    private readonly ApplicationDbContext _db;
    public StudentController(ApplicationDbContext db) => _db = db;

    private int? StudentId => HttpContext.Session.GetInt32("StudentId");

    private IActionResult LoginRedirect() => RedirectToAction("Login", "Account");

    [HttpGet]
    public async Task<IActionResult> Dashboard()
    {
        if (StudentId == null) return LoginRedirect();
        var student = await _db.Students.FindAsync(StudentId.Value);
        if (student == null) return LoginRedirect();

        var now = DateTime.Now;
        var available = await _db.Exams
            .Where(e => e.TargetClass == student.ClassName && e.TargetDivision == student.Division && e.StartDate <= now && e.EndDate >= now)
            .OrderBy(e => e.EndDate)
            .ToListAsync();

        var attempts = await _db.ExamAttempts
            .Include(a => a.Exam)
            .Where(a => a.StudentId == StudentId.Value && a.SubmittedAt != null)
            .OrderByDescending(a => a.SubmittedAt)
            .Take(5)
            .ToListAsync();

        ViewBag.Available = available;
        ViewBag.Attempts = attempts;
        return View(student);
    }

    [HttpGet]
    public async Task<IActionResult> Exams()
    {
        if (StudentId == null) return LoginRedirect();
        var student = await _db.Students.FindAsync(StudentId.Value);
        if (student == null) return LoginRedirect();

        var now = DateTime.Now;
        var exams = await _db.Exams
            .Include(e => e.Teacher)
            .Where(e => e.TargetClass == student.ClassName && e.TargetDivision == student.Division && e.StartDate <= now && e.EndDate >= now)
            .OrderBy(e => e.EndDate)
            .ToListAsync();

        var completed = await _db.ExamAttempts
            .Where(a => a.StudentId == StudentId.Value && a.SubmittedAt != null)
            .Select(a => a.ExamId)
            .ToListAsync();

        ViewBag.Completed = completed;
        return View(exams);
    }

    [HttpGet]
    public async Task<IActionResult> StartExam(int id)
    {
        if (StudentId == null) return LoginRedirect();
        var student = await _db.Students.FindAsync(StudentId.Value);
        var exam = await _db.Exams.Include(e => e.Questions).ThenInclude(q => q.Options).FirstOrDefaultAsync(e => e.ExamId == id);
        if (student == null || exam == null) return NotFound();

        var now = DateTime.Now;
        if (exam.TargetClass != student.ClassName || exam.TargetDivision != student.Division || now < exam.StartDate || now > exam.EndDate)
        {
            TempData["Error"] = "This examination is not currently available for your class and division.";
            return RedirectToAction(nameof(Exams));
        }

        var existing = await _db.ExamAttempts.FirstOrDefaultAsync(a => a.ExamId == id && a.StudentId == StudentId.Value && a.SubmittedAt == null);
        if (existing != null) return RedirectToAction(nameof(TakeExam), new { id = existing.ExamAttemptId });

        var completed = await _db.ExamAttempts.AnyAsync(a => a.ExamId == id && a.StudentId == StudentId.Value && a.SubmittedAt != null);
        if (completed)
        {
            TempData["Error"] = "You have already completed this examination.";
            return RedirectToAction(nameof(Exams));
        }

        var attempt = new Models.ExamAttempt
        {
            ExamId = exam.ExamId,
            StudentId = StudentId.Value,
            StartedAt = now
        };
        _db.ExamAttempts.Add(attempt);
        await _db.SaveChangesAsync();
        return RedirectToAction(nameof(TakeExam), new { id = attempt.ExamAttemptId });
    }

    [HttpGet]
    public async Task<IActionResult> TakeExam(int id)
    {
        if (StudentId == null) return LoginRedirect();
        var attempt = await _db.ExamAttempts
            .Include(a => a.Exam!).ThenInclude(e => e.Questions).ThenInclude(q => q.Options)
            .FirstOrDefaultAsync(a => a.ExamAttemptId == id && a.StudentId == StudentId.Value);
        if (attempt == null) return NotFound();
        if (attempt.SubmittedAt != null) return RedirectToAction(nameof(Result), new { id = attempt.ExamAttemptId });

        var deadline = attempt.StartedAt.AddMinutes(attempt.Exam!.DurationMinutes);
        if (DateTime.Now >= deadline)
            return RedirectToAction(nameof(SubmitExam), new { id = attempt.ExamAttemptId });

        return View(attempt);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> SubmitExam(int id, Dictionary<int, int?> answers)
    {
        if (StudentId == null) return LoginRedirect();
        var attempt = await _db.ExamAttempts
            .Include(a => a.Exam!).ThenInclude(e => e.Questions).ThenInclude(q => q.Options)
            .FirstOrDefaultAsync(a => a.ExamAttemptId == id && a.StudentId == StudentId.Value);
        if (attempt == null) return NotFound();
        if (attempt.SubmittedAt != null) return RedirectToAction(nameof(Result), new { id });

        var score = 0;
        foreach (var question in attempt.Exam!.Questions)
        {
            answers.TryGetValue(question.QuestionId, out var selectedId);
            var selected = question.Options.FirstOrDefault(o => o.OptionId == selectedId);
            var correct = selected?.IsCorrect == true;
            var marks = correct ? question.Marks : 0;
            score += marks;
            _db.StudentAnswers.Add(new Models.StudentAnswer
            {
                ExamAttemptId = attempt.ExamAttemptId,
                QuestionId = question.QuestionId,
                SelectedOptionId = selectedId,
                IsCorrect = correct,
                MarksObtained = marks
            });
        }

        attempt.Score = score;
        attempt.Percentage = attempt.Exam.TotalMarks == 0 ? 0 : Math.Round(score * 100.0 / attempt.Exam.TotalMarks, 2);
        attempt.SubmittedAt = DateTime.Now;
        await _db.SaveChangesAsync();

        return RedirectToAction(nameof(Result), new { id = attempt.ExamAttemptId });
    }

    [HttpGet]
    public async Task<IActionResult> SubmitExam(int id)
    {
        return await SubmitExam(id, new Dictionary<int, int?>());
    }

    [HttpGet]
    public async Task<IActionResult> Result(int id)
    {
        if (StudentId == null) return LoginRedirect();
        var attempt = await _db.ExamAttempts.Include(a => a.Exam).FirstOrDefaultAsync(a => a.ExamAttemptId == id && a.StudentId == StudentId.Value);
        if (attempt == null) return NotFound();
        if (attempt.SubmittedAt == null) return RedirectToAction(nameof(TakeExam), new { id });
        return View(attempt);
    }

    [HttpGet]
    public async Task<IActionResult> Results()
    {
        if (StudentId == null) return LoginRedirect();
        var attempts = await _db.ExamAttempts.Include(a => a.Exam).Where(a => a.StudentId == StudentId.Value && a.SubmittedAt != null).OrderByDescending(a => a.SubmittedAt).ToListAsync();
        return View(attempts);
    }

    [HttpGet]
    public async Task<IActionResult> Ranking(int id)
    {
        if (StudentId == null) return LoginRedirect();
        var exam = await _db.Exams.FindAsync(id);
        if (exam == null) return NotFound();
        var ranking = await _db.ExamAttempts.Include(a => a.Student).Where(a => a.ExamId == id && a.SubmittedAt != null).OrderByDescending(a => a.Score).ThenBy(a => a.SubmittedAt).ToListAsync();
        ViewBag.Exam = exam;
        ViewBag.CurrentStudentId = StudentId.Value;
        return View(ranking);
    }

    [HttpGet]
    public async Task<IActionResult> Profile()
    {
        if (StudentId == null) return LoginRedirect();
        var student = await _db.Students.FindAsync(StudentId.Value);
        if (student == null) return LoginRedirect();
        return View(student);
    }
}
