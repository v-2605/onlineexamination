# ExamSphere - Online Examination System

A clean ASP.NET Core MVC mini-project for college demonstrations.

## Stack
- ASP.NET Core MVC (.NET 10)
- Entity Framework Core
- SQLite
- Razor Views
- Session authentication
- Password hashing with ASP.NET Core Identity's PasswordHasher

## Features
- Student registration with class as free text and division dropdown A-F/LS
- Student login
- Teacher login
- Student dashboard
- Teacher dashboard
- Teacher exam creation
- Multiple-choice question builder
- Marks and duration
- Exam scheduling
- Class/division targeting without ClassId or DivisionId
- Timed student examination
- Automatic marking
- Results and percentage
- Exam leaderboard/ranking
- Teacher submissions
- Student list
- Responsive aesthetic UI

## Run in VS Code
1. Install the .NET 10 SDK.
2. Open this folder in VS Code.
3. Open the integrated terminal.
4. Run:

```bash
dotnet restore
dotnet run
```

5. Open the URL shown in the terminal.

The SQLite database file `onlineexamination.db` is created automatically on first run. No SQL Server or manual migration is required.

## Demo accounts
Teacher:
- Email: teacher@examsphere.com
- Password: Teacher@123
- Select: Teacher

Student:
- Email: student@examsphere.com
- Password: Student@123
- Select: Student

## Student registration
Students enter their own:
- Full name
- Email
- Password
- Roll number
- Class (for example SY, TY, FY BSc IT)
- Division (A, B, C, D, E, F or LS)

There are no Class ID or Division ID fields.

## Reset the demo database
Stop the application and delete `onlineexamination.db`. Run the application again and the demo data will be recreated.
