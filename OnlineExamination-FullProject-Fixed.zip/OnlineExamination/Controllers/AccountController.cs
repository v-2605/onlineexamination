using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OnlineExamination.Data;
using OnlineExamination.Models;

namespace OnlineExamination.Controllers;

public class AccountController : Controller
{
    private readonly ApplicationDbContext _db;
    private readonly PasswordHasher<Student> _studentHasher = new();
    private readonly PasswordHasher<Teacher> _teacherHasher = new();

    public AccountController(ApplicationDbContext db) => _db = db;

    [HttpGet]
    public IActionResult Login() => View();

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Login(string email, string password, string role)
    {
        if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password) || string.IsNullOrWhiteSpace(role))
        {
            ViewBag.Error = "Please enter all login details.";
            return View();
        }

        email = email.Trim();

        if (role == "Student")
        {
            var student = await _db.Students.FirstOrDefaultAsync(x => x.Email == email);
            if (student == null || _studentHasher.VerifyHashedPassword(student, student.PasswordHash, password) == PasswordVerificationResult.Failed)
            {
                ViewBag.Error = "Invalid student email or password.";
                return View();
            }

            HttpContext.Session.SetInt32("StudentId", student.StudentId);
            HttpContext.Session.SetString("UserRole", "Student");
            return RedirectToAction("Dashboard", "Student");
        }

        if (role == "Teacher")
        {
            var teacher = await _db.Teachers.FirstOrDefaultAsync(x => x.Email == email);
            if (teacher == null || _teacherHasher.VerifyHashedPassword(teacher, teacher.PasswordHash, password) == PasswordVerificationResult.Failed)
            {
                ViewBag.Error = "Invalid teacher email or password.";
                return View();
            }

            HttpContext.Session.SetInt32("TeacherId", teacher.TeacherId);
            HttpContext.Session.SetString("UserRole", "Teacher");
            return RedirectToAction("Dashboard", "Teacher");
        }

        ViewBag.Error = "Please choose Student or Teacher.";
        return View();
    }

    [HttpGet]
    public IActionResult Register() => View(new RegisterStudentViewModel());

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Register(RegisterStudentViewModel model)
    {
        if (!ModelState.IsValid) return View(model);

        if (await _db.Students.AnyAsync(x => x.Email == model.Email.Trim()))
        {
            ModelState.AddModelError(nameof(model.Email), "This email is already registered.");
            return View(model);
        }

        if (await _db.Teachers.AnyAsync(x => x.Email == model.Email.Trim()))
        {
            ModelState.AddModelError(nameof(model.Email), "This email is already used by a teacher.");
            return View(model);
        }

        var student = new Student
        {
            FullName = model.FullName.Trim(),
            Email = model.Email.Trim().ToLowerInvariant(),
            RollNumber = model.RollNumber.Trim(),
            ClassName = model.ClassName.Trim(),
            Division = model.Division.Trim()
        };
        student.PasswordHash = _studentHasher.HashPassword(student, model.Password);

        _db.Students.Add(student);
        await _db.SaveChangesAsync();

        TempData["Success"] = "Account created successfully. You can now log in.";
        return RedirectToAction(nameof(Login));
    }

    public IActionResult Logout()
    {
        HttpContext.Session.Clear();
        return RedirectToAction(nameof(Login));
    }
}
