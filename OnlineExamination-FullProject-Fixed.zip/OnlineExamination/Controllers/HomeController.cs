using Microsoft.AspNetCore.Mvc;

namespace OnlineExamination.Controllers;

public class HomeController : Controller
{
    public IActionResult Index()
    {
        if (HttpContext.Session.GetString("UserRole") == "Student")
            return RedirectToAction("Dashboard", "Student");

        if (HttpContext.Session.GetString("UserRole") == "Teacher")
            return RedirectToAction("Dashboard", "Teacher");

        return View();
    }

    public IActionResult Error() => View();
}
