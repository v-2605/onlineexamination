using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OnlineExamination.Data;
using OnlineExamination.Models;

namespace OnlineExamination.Controllers;

public class TeacherController : Controller
{
    private readonly ApplicationDbContext _db;
    public TeacherController(ApplicationDbContext db) => _db = db;

    private int? TeacherId => HttpContext.Session.GetInt32("TeacherId");
    private IActionResult LoginRedirect() => RedirectToAction("Login", "Account");

    [HttpGet]
    public async Task<IActionResult> Dashboard()
    {
        if (TeacherId == null) return LoginRedirect();
        var teacher = await _db.Teachers.FindAsync(TeacherId.Value);
        if (teacher == null) return LoginRedirect();
        var exams = await _db.Exams.Where(e => e.TeacherId == TeacherId.Value).OrderByDescending(e => e.StartDate).ToListAsync();
        ViewBag.ExamCount = exams.Count;
        ViewBag.QuestionCount = await _db.Questions.CountAsync(q => q.Exam!.TeacherId == TeacherId.Value);
        ViewBag.AttemptCount = await _db.ExamAttempts.CountAsync(a => a.Exam!.TeacherId == TeacherId.Value && a.SubmittedAt != null);
        ViewBag.StudentCount = await _db.Students.CountAsync();
        ViewBag.RecentExams = exams.Take(5).ToList();
        return View(teacher);
    }

    [HttpGet]
    public async Task<IActionResult> Exams()
    {
        if (TeacherId == null) return LoginRedirect();
        var exams = await _db.Exams.Where(e => e.TeacherId == TeacherId.Value).OrderByDescending(e => e.StartDate).ToListAsync();
        return View(exams);
    }

    [HttpGet]
    public IActionResult CreateExam()
    {
        if (TeacherId == null) return LoginRedirect();
        return View(new CreateExamViewModel
        {
            StartDate = DateTime.Now,
            EndDate = DateTime.Now.AddDays(7),
            TargetClass = "SY",
            TargetDivision = "A"
        });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> CreateExam(CreateExamViewModel model)
    {
        if (TeacherId == null) return LoginRedirect();
        if (model.EndDate <= model.StartDate) ModelState.AddModelError(nameof(model.EndDate), "End date must be after the start date.");
        if (!ModelState.IsValid) return View(model);

        var exam = new Exam
        {
            Title = model.Title.Trim(),
            Description = model.Description?.Trim() ?? "",
            DurationMinutes = model.DurationMinutes,
            StartDate = model.StartDate,
            EndDate = model.EndDate,
            TargetClass = model.TargetClass.Trim(),
            TargetDivision = model.TargetDivision.Trim(),
            TeacherId = TeacherId.Value,
            TotalMarks = 0
        };
        _db.Exams.Add(exam);
        await _db.SaveChangesAsync();
        return RedirectToAction(nameof(EditExam), new { id = exam.ExamId });
    }

    [HttpGet]
    public async Task<IActionResult> EditExam(int id)
    {
        if (TeacherId == null) return LoginRedirect();
        var exam = await _db.Exams.Include(e => e.Questions).ThenInclude(q => q.Options).FirstOrDefaultAsync(e => e.ExamId == id && e.TeacherId == TeacherId.Value);
        if (exam == null) return NotFound();
        return View(exam);
    }

    [HttpGet]
    public async Task<IActionResult> AddQuestion(int examId)
    {
        if (TeacherId == null) return LoginRedirect();
        var exam = await _db.Exams.FirstOrDefaultAsync(e => e.ExamId == examId && e.TeacherId == TeacherId.Value);
        if (exam == null) return NotFound();
        ViewBag.Exam = exam;
        return View(new CreateQuestionViewModel { ExamId = examId });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> AddQuestion(CreateQuestionViewModel model)
    {
        if (TeacherId == null) return LoginRedirect();
        var exam = await _db.Exams.FirstOrDefaultAsync(e => e.ExamId == model.ExamId && e.TeacherId == TeacherId.Value);
        if (exam == null) return NotFound();
        if (!ModelState.IsValid)
        {
            ViewBag.Exam = exam;
            return View(model);
        }

        var options = new List<Option>
        {
            new() { OptionText = model.OptionA.Trim(), IsCorrect = model.CorrectOption == 1 },
            new() { OptionText = model.OptionB.Trim(), IsCorrect = model.CorrectOption == 2 },
            new() { OptionText = model.OptionC.Trim(), IsCorrect = model.CorrectOption == 3 },
            new() { OptionText = model.OptionD.Trim(), IsCorrect = model.CorrectOption == 4 }
        };
        exam.Questions.Add(new Question { QuestionText = model.QuestionText.Trim(), Marks = model.Marks, Options = options });
        exam.TotalMarks += model.Marks;
        await _db.SaveChangesAsync();
        return RedirectToAction(nameof(EditExam), new { id = exam.ExamId });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteQuestion(int id)
    {
        if (TeacherId == null) return LoginRedirect();
        var question = await _db.Questions.Include(q => q.Exam).FirstOrDefaultAsync(q => q.QuestionId == id && q.Exam!.TeacherId == TeacherId.Value);
        if (question == null) return NotFound();
        var exam = question.Exam!;
        exam.TotalMarks = Math.Max(0, exam.TotalMarks - question.Marks);
        _db.Questions.Remove(question);
        await _db.SaveChangesAsync();
        return RedirectToAction(nameof(EditExam), new { id = exam.ExamId });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteExam(int id)
    {
        if (TeacherId == null) return LoginRedirect();
        var exam = await _db.Exams.FirstOrDefaultAsync(e => e.ExamId == id && e.TeacherId == TeacherId.Value);
        if (exam == null) return NotFound();
        _db.Exams.Remove(exam);
        await _db.SaveChangesAsync();
        return RedirectToAction(nameof(Exams));
    }

    [HttpGet]
    public async Task<IActionResult> Submissions(int id)
    {
        if (TeacherId == null) return LoginRedirect();
        var exam = await _db.Exams.FirstOrDefaultAsync(e => e.ExamId == id && e.TeacherId == TeacherId.Value);
        if (exam == null) return NotFound();
        var submissions = await _db.ExamAttempts.Include(a => a.Student).Where(a => a.ExamId == id && a.SubmittedAt != null).OrderByDescending(a => a.Score).ThenBy(a => a.SubmittedAt).ToListAsync();
        ViewBag.Exam = exam;
        return View(submissions);
    }

    [HttpGet]
    public async Task<IActionResult> Students()
    {
        if (TeacherId == null) return LoginRedirect();
        var students = await _db.Students.OrderBy(s => s.ClassName).ThenBy(s => s.Division).ThenBy(s => s.RollNumber).ToListAsync();
        return View(students);
    }
}
