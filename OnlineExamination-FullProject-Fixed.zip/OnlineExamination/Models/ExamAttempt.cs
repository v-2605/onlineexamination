namespace OnlineExamination.Models;

public class ExamAttempt
{
    public int ExamAttemptId { get; set; }
    public int StudentId { get; set; }
    public int ExamId { get; set; }
    public DateTime StartedAt { get; set; }
    public DateTime? SubmittedAt { get; set; }
    public int Score { get; set; }
    public double Percentage { get; set; }

    public Student? Student { get; set; }
    public Exam? Exam { get; set; }
    public ICollection<StudentAnswer> Answers { get; set; } = new List<StudentAnswer>();
}
