using System.ComponentModel.DataAnnotations;

namespace OnlineExamination.Models;

public class Student
{
    public int StudentId { get; set; }

    [Required, StringLength(100)]
    public string FullName { get; set; } = "";

    [Required, EmailAddress, StringLength(150)]
    public string Email { get; set; } = "";

    [Required]
    public string PasswordHash { get; set; } = "";

    [Required, StringLength(50)]
    public string RollNumber { get; set; } = "";

    [Required, StringLength(50)]
    public string ClassName { get; set; } = "";

    [Required, StringLength(10)]
    public string Division { get; set; } = "";

    public ICollection<ExamAttempt> Attempts { get; set; } = new List<ExamAttempt>();
}
