namespace OnlineExamination.Models;

public class StudentAnswer
{
    public int StudentAnswerId { get; set; }
    public int ExamAttemptId { get; set; }
    public int QuestionId { get; set; }
    public int? SelectedOptionId { get; set; }
    public bool IsCorrect { get; set; }
    public int MarksObtained { get; set; }

    public ExamAttempt? Attempt { get; set; }
    public Question? Question { get; set; }
    public Option? SelectedOption { get; set; }
}
