using System.ComponentModel.DataAnnotations;

namespace OnlineExamination.Models;

public class Teacher
{
    public int TeacherId { get; set; }

    [Required, StringLength(100)]
    public string FullName { get; set; } = "";

    [Required, EmailAddress, StringLength(150)]
    public string Email { get; set; } = "";

    [Required]
    public string PasswordHash { get; set; } = "";

    [StringLength(100)]
    public string Subject { get; set; } = "";

    public ICollection<Exam> Exams { get; set; } = new List<Exam>();
}
