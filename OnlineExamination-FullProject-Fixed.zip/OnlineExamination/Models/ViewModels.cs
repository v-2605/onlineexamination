using System.ComponentModel.DataAnnotations;

namespace OnlineExamination.Models;

public class RegisterStudentViewModel
{
    [Required, StringLength(100)] public string FullName { get; set; } = "";
    [Required, EmailAddress] public string Email { get; set; } = "";
    [Required, MinLength(6)] public string Password { get; set; } = "";
    [Required, StringLength(50)] public string RollNumber { get; set; } = "";
    [Required, StringLength(50)] public string ClassName { get; set; } = "";
    [Required] public string Division { get; set; } = "";
}

public class CreateExamViewModel
{
    [Required, StringLength(150)] public string Title { get; set; } = "";
    [StringLength(600)] public string Description { get; set; } = "";
    [Range(1, 300)] public int DurationMinutes { get; set; } = 30;
    [Required] public string TargetClass { get; set; } = "SY";
    [Required] public string TargetDivision { get; set; } = "A";
    [DataType(DataType.DateTime)] public DateTime StartDate { get; set; } = DateTime.Now;
    [DataType(DataType.DateTime)] public DateTime EndDate { get; set; } = DateTime.Now.AddDays(7);
}

public class CreateQuestionViewModel
{
    public int ExamId { get; set; }
    [Required, StringLength(1000)] public string QuestionText { get; set; } = "";
    [Range(1, 100)] public int Marks { get; set; } = 1;
    [Required] public string OptionA { get; set; } = "";
    [Required] public string OptionB { get; set; } = "";
    [Required] public string OptionC { get; set; } = "";
    [Required] public string OptionD { get; set; } = "";
    [Range(1, 4)] public int CorrectOption { get; set; } = 1;
}
