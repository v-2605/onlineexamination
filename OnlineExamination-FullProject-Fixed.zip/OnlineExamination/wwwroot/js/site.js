const ExamTimer = {
    init() {
        const el = document.getElementById('timer');
        const form = document.getElementById('examForm');
        if (!el || !form) return;
        let remaining = parseInt(el.dataset.seconds || '0', 10);
        const render = () => {
            const min = Math.floor(remaining / 60).toString().padStart(2, '0');
            const sec = (remaining % 60).toString().padStart(2, '0');
            el.textContent = `${min}:${sec}`;
            if (remaining <= 60) el.style.background = '#b8324b';
        };
        render();
        const interval = setInterval(() => {
            remaining--;
            render();
            if (remaining <= 0) {
                clearInterval(interval);
                form.submit();
            }
        }, 1000);
    }
};
