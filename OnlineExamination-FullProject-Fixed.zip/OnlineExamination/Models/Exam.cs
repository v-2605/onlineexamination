using System.ComponentModel.DataAnnotations;

namespace OnlineExamination.Models;

public class Exam
{
    public int ExamId { get; set; }

    [Required, StringLength(150)]
    public string Title { get; set; } = "";

    [StringLength(600)]
    public string Description { get; set; } = "";

    [Range(1, 300)]
    public int DurationMinutes { get; set; } = 30;

    public int TotalMarks { get; set; }

    [DataType(DataType.DateTime)]
    public DateTime StartDate { get; set; } = DateTime.Now;

    [DataType(DataType.DateTime)]
    public DateTime EndDate { get; set; } = DateTime.Now.AddDays(7);

    [Required, StringLength(50)]
    public string TargetClass { get; set; } = "";

    [Required, StringLength(10)]
    public string TargetDivision { get; set; } = "";

    public int TeacherId { get; set; }
    public Teacher? Teacher { get; set; }

    public ICollection<Question> Questions { get; set; } = new List<Question>();
    public ICollection<ExamAttempt> Attempts { get; set; } = new List<ExamAttempt>();
}
